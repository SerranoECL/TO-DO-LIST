const button = document.querySelector(".button-add-task");
const input = document.querySelector(".input-task");
const listaCompleta = document.querySelector(".list-tasks");

let list = getListFromLocalStorage();

function getListFromLocalStorage() {
  let list = [];

  let localStorageList = localStorage.getItem("list");
  if (localStorageList) {
    list = JSON.parse(localStorageList);
  }

  return list;
}

function grabInput() {
  console.log("Text Box:", input.value);
  list.push(input.value);
}

function addTask() {
  grabInput();
  localStorage.setItem("list", JSON.stringify(list));
  refreshTasks();
  input.value =''
}

function refreshTasks() {
  let novaLi = "";

  list.forEach((task) => {
    novaLi =
      novaLi +
      `<li class="task">
				<img src="./img/check-mark-tick-clip-art-green-nrg-co.jpg" alt="check-na-tarefa">
				<p>${task}</p>
				<img src="./img/pngtree-rounded-raster-icon-of-a-flat-redcolored-photo-png-image_13892531.png" alt="tarefa-para-o-lixo" onclick="apagarItem()">
			</li>`;
  });

  listaCompleta.innerHTML = novaLi;
}

refreshTasks();

function apagarItem() {
  console.log("apagar")
}

button.addEventListener("click", addTask);
 